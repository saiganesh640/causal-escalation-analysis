import json 
import csv 
import os 
from collections import defaultdict 
INPUT_JSON = "data/Conversational_Transcript_Dataset.json" 
OUTPUT_CSV = "data/conversations.csv"
OUTPUT_GT  = "data/ground_truth_calls.csv" 
def infer_outcome(domain: str, intent: str, reason: str, convo_text: str) -> str:
    text = f"{domain} {intent} {reason} {convo_text}".lower()

    if any(k in text for k in [
        "escalation", "escalate", "supervisor", "manager", "legal", "lawyer",
        "formal complaint", "complaint"
    ]):
        return "escalation_or_complaint"

    if any(k in text for k in [
        "delivery investigation", "marked as delivered", "never received",
        "delivery", "order"
    ]):
        return "delivery_issue"

    if any(k in text for k in ["system outage", "planned outage"]):
        return "system_outage"

    if any(k in text for k in [
        "service interruptions", "service interruption", "outage"
    ]):
        return "service_interruption"

    if any(k in text for k in [
        "claim denials", "claim denial", "denial", "appeal", "claim"
    ]):
        return "claim_denial"

    return "general_support"


def main(): 
    os.makedirs("data", exist_ok=True) 
os.makedirs("outputs", exist_ok=True) 
with open(INPUT_JSON, "r", encoding="utf-8") as f: 
        data = json.load(f) 
 
transcripts = data.get("transcripts", data)  # supports {"transcripts":[...]} or list[...] 
 
rows = [] 
gt = defaultdict(set) 
 
for t in transcripts: 
        call_id = t.get("transcript_id") or t.get("call_id") or t.get("id") 
        domain = t.get("domain", "") 
        intent = t.get("intent", "") 
        reason = t.get("reason_for_call", "") 
        convo = t.get("conversation", []) 
 
        convo_text = " ".join([str(x.get("text", "")) for x in convo]) 
        outcome = infer_outcome(domain, intent, reason, convo_text) 
 
        if call_id: 
            gt[outcome].add(call_id) 
 
        for i, turn in enumerate(convo, start=1): 
            rows.append({ 
                "call_id": call_id, 
                "turn_id": i, 
                "speaker": str(turn.get("speaker", "")).strip().lower(),  # agent/customer 
                "text": str(turn.get("text", "")).strip(), 
                "outcome": outcome, 
                "domain": domain, 
                "intent": intent, 
                "reason_for_call": reason, 
            }) 
 
with open(OUTPUT_CSV, "w", newline="", encoding="utf-8") as f: 
        w = csv.DictWriter( 
            f, 
            
fieldnames=["call_id","turn_id","speaker","text","outcome","domain","intent","reason_for_call"] 
        ) 
        w.writeheader() 
        w.writerows(rows) 
 
with open(OUTPUT_GT, "w", newline="", encoding="utf-8") as f: 
        w = csv.writer(f) 
        w.writerow(["outcome", "expected_call_ids"]) 
        for outcome, ids in sorted(gt.items()): 
            w.writerow([outcome, " ".join(sorted(ids))]) 
 
print(f" Created {OUTPUT_CSV} with {len(rows)} turns") 
print(f" Created {OUTPUT_GT} for ID Recall reference")