import csv
import json
import os
import requests

API = "http://127.0.0.1:8000"
IN_QUERIES = "../queries.csv"
OUT_QUERIES = "outputs/queries_filled.csv"


def post(endpoint: str, payload: dict):
    r = requests.post(f"{API}{endpoint}", json=payload, timeout=30)
    r.raise_for_status()
    return r.json()


def infer_outcome(q: str) -> str:
    ql = q.lower()

    if "delivery_issue" in ql or "delivery" in ql:
        return "delivery_issue"

    if "system_outage" in ql or "outage" in ql:
        return "system_outage"

    if "service_interruption" in ql or "interruption" in ql:
        return "service_interruption"

    if "claim_denial" in ql or "claim" in ql or "denial" in ql:
        return "claim_denial"

    if (
        "escalation_or_complaint" in ql
        or "escalat" in ql
        or "complain" in ql
        or "legal" in ql
    ):
        return "escalation_or_complaint"

    return "general_support"


def main():
    os.makedirs("outputs", exist_ok=True)

    with open(IN_QUERIES, "r", encoding="utf-8") as f:
        rows = list(csv.DictReader(f))

    session_map = {
        "escalation_or_complaint": "sess_escalation",
        "delivery_issue": "sess_delivery",
        "system_outage": "sess_outage",
        "service_interruption": "sess_interruption",
        "claim_denial": "sess_claim",
        "general_support": "sess_general",
    }

    out_rows = []

    for row in rows:
        q = row["Query"]
        cat = row["Query Category"].strip().lower()

        outcome = infer_outcome(q)
        session_id = session_map.get(outcome, "demo")

        if cat == "task1":
            resp = post(
                "/analyze",
                {"session_id": session_id, "query": q, "outcome": outcome},
            )
        else:
            resp = post(
                "/followup",
                {"session_id": session_id, "query": q, "outcome": outcome},
            )

        row["System Output"] = json.dumps(resp, ensure_ascii=False)
        row["Remarks"] = "Auto-generated"

        # 🔥 IMPORTANT: clean column names (remove extra spaces)
        row = {k.strip(): v for k, v in row.items()}

        out_rows.append(row)

    with open(OUT_QUERIES, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(
            f,
            fieldnames=[
                "Query Id",
                "Query",
                "Query Category",
                "System Output",
                "Remarks",
            ],
        )
        w.writeheader()
        w.writerows(out_rows)

    print(f"Wrote {OUT_QUERIES}")


if __name__ == "__main__":
    main()
