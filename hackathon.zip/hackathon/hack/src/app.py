from fastapi import FastAPI
from pydantic import BaseModel
from typing import Optional, Dict, Any, List

from src.preprocess import load_conversations
from src.causal_engine import detect_factors
from src.evidence import select_evidence_spans
from src.session import SessionManager

DATA_PATH = "data/conversations.csv"

app = FastAPI(title="Causal Analysis & Interactive Reasoning (Evidence-grounded)")
sessions = SessionManager()


def get_data() -> List[dict]:
    return load_conversations(DATA_PATH)


class QueryRequest(BaseModel):
    session_id: str = "demo"
    query: str
    outcome: Optional[str] = None
    top_k_calls: int = 20


def infer_outcome_from_query(q: str) -> Optional[str]:
    ql = q.lower()

    if "delivery" in ql:
        return "delivery_issue"

    if "system outage" in ql or "planned outage" in ql or "outage" in ql:
        return "system_outage"

    if "interruption" in ql:
        return "service_interruption"

    if "claim" in ql or "denial" in ql:
        return "claim_denial"

    if "escalat" in ql or "complain" in ql or "legal" in ql:
        return "escalation_or_complaint"

    return None


def turns_for_outcome(all_turns: List[dict], outcome: str) -> List[dict]:
    return [t for t in all_turns if t["outcome"] == outcome]


@app.post("/analyze")
def analyze(req: QueryRequest) -> Dict[str, Any]:
    st = sessions.get(req.session_id)

    outcome = req.outcome or infer_outcome_from_query(req.query) or st.last_outcome
    if not outcome:
        return {
            "error": "Provide outcome or include it in your query (e.g., delivery/system outage/claim denial/escalation)."
        }

    all_turns = get_data()
    turns = turns_for_outcome(all_turns, outcome)

    call_ids = sorted({t["call_id"] for t in turns if t.get("call_id")})[: req.top_k_calls]

    factor_hits = detect_factors(turns)
    factors = select_evidence_spans(factor_hits, max_turns_per_factor=3)

    resp = {
        "session_id": req.session_id,
        "outcome": outcome,
        "causal_explanation": {
            "summary": f"Detected {len(factors)} causal factors for outcome '{outcome}'.",
            "factors": factors,
        },
        "retrieved_call_ids": call_ids,
        "faithfulness_note": "All factors include message-level evidence (call_id + turn_id + text).",
    }

    sessions.update(
        req.session_id,
        last_query=req.query,
        last_outcome=outcome,
        last_call_ids=call_ids,
        last_factors=factors,
    )

    return resp


@app.post("/followup")
def followup(req: QueryRequest) -> Dict[str, Any]:
    st = sessions.get(req.session_id)

    outcome = req.outcome or infer_outcome_from_query(req.query) or st.last_outcome
    if not outcome or not st.last_outcome:
        return {"error": "Call /analyze first, then ask follow-ups."}

    ql = req.query.lower()

    if "evidence" in ql or "proof" in ql or "show" in ql:
        return {
            "session_id": req.session_id,
            "outcome": outcome,
            "answer": "Evidence used in the previous explanation.",
            "factors": st.last_factors,
        }

    if "which factor" in ql or "top" in ql or "most" in ql:
        ranked = sorted(
            st.last_factors, key=lambda x: len(x["evidence"]), reverse=True
        )
        return {
            "session_id": req.session_id,
            "outcome": outcome,
            "answer": "Factors ranked by evidence count within the same analysis context.",
            "factors_ranked": [
                {"factor": f["factor"], "evidence_count": len(f["evidence"])}
                for f in ranked
            ],
        }

    if "call id" in ql or "which calls" in ql:
        return {
            "session_id": req.session_id,
            "outcome": outcome,
            "answer": "Call IDs used in the last analysis.",
            "retrieved_call_ids": st.last_call_ids,
        }

    return analyze(req)
