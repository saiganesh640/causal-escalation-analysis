import csv 
from typing import List, Dict 
 
def load_conversations(csv_path: str) -> List[Dict]: 
    rows = [] 
    with open(csv_path, "r", encoding="utf-8") as f:
        reader = csv.DictReader(f) 
        for r in reader: 
            rows.append({ 
                "call_id": r["call_id"], 
                "turn_id": int(r["turn_id"]), 
                "speaker": r["speaker"].strip().lower(), 
                "text": r["text"].strip(), 
                "outcome": r["outcome"].strip().lower(), 
                "domain": r.get("domain", "").strip(), 
                "intent": r.get("intent", "").strip(), 
"reason_for_call": r.get("reason_for_call", "").strip(), 
}) 
            return rows 