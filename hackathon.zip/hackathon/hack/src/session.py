from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional


@dataclass
class SessionState:
    last_query: Optional[str] = None
    last_outcome: Optional[str] = None
    last_call_ids: List[str] = field(default_factory=list)
    last_factors: List[Dict[str, Any]] = field(default_factory=list)


class SessionManager:
    def __init__(self):
        self.sessions: Dict[str, SessionState] = {}

    def get(self, session_id: str) -> SessionState:
        if session_id not in self.sessions:
            self.sessions[session_id] = SessionState()
        return self.sessions[session_id]

    def update(self, session_id: str, **kwargs):
        st = self.get(session_id)
        for k, v in kwargs.items():
            setattr(st, k, v)
