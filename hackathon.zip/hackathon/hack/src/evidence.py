from typing import List, Dict, Any 
 
def select_evidence_spans(factor_hits: List[Any], max_turns_per_factor: int = 3) -> List[Dict]: 
    out = [] 
    for hit in factor_hits: 
        out.append({ 
            "factor_id": hit.factor_id, 
            "factor": hit.factor_name, 
            "why_it_matters": hit.why_it_matters, 
            "evidence": hit.matched_turns[:max_turns_per_factor], 
        }) 
    return out