from dataclasses import dataclass
from typing import Dict, List

@dataclass
class FactorID:
    factor_name: str
    why_it_matters: str
    matched_turns: List[dict] 
CAUSAL_PATTERNS: Dict[str, dict] = { 
"agent_delay_deflection": { 
"name": "Agent delay / deflection", 
"why": "Delays or deflection can stall resolution and increase dissatisfaction, leading to escalation/complaints.", 
"terms": ["wait", "business days", "investigation", "cannot", "not possible", "policy", "in review"], 
}, 
"repeat_unresolved_issue": { 
"name": "Repeated unresolved issue", 
"why": "When the customer repeats that the issue persists or steps were already tried, escalation likelihood rises.", 
        "terms": ["again", "still", "already", "multiple times", "third time", "same issue", "not working"], 
    }, 
    "customer_escalation_intent": { 
        "name": "Customer escalation / complaint intent", 
        "why": "Explicit requests for supervisor/complaint/legal action strongly correlate with escalation outcomes.", 
        "terms": ["supervisor", "manager", "complaint", "formal complaint", "escalate", "legal", 
"lawyer"], 
    }, 
    "lack_of_notification": { 
        "name": "Lack of notification / surprise event", 
        "why": "If a customer indicates they were not informed (e.g., outage), dissatisfaction increases even if resolved later.", 
        "terms": ["wasn't notified", "not informed", "why wasn't i notified", "didn't receive any notification"], 
    }, 
    "high_urgency_impact": { 
        "name": "High urgency / customer impact", 
        "why": "High urgency increases risk: if resolution is slow, outcomes shift toward complaints/escalation.", 
        "terms": ["urgent", "today", "asap", "important meeting", "affecting my job", "deadline"], 
    }, 
} 
 
def detect_factors(turns: List[dict]) -> List[FactorID]: 
    hits: Dict[str, FactorHit] = {} 
    for t in turns: 
        text_l = t["text"].lower() 
        for factor_id, meta in CAUSAL_PATTERNS.items(): 
            for term in meta["terms"]: 
                if term in text_l: 
                    if factor_id not in hits: 
                        hits[factor_id] = FactorHit( 
                            factor_id=factor_id, 
                            factor_name=meta["name"], 
                            why_it_matters=meta["why"], 
                            matched_turns=[] 
                        ) 
                    hits[factor_id].matched_turns.append({ 
                        "call_id": t["call_id"], 
                        "turn_id": t["turn_id"], 
                        "speaker": t["speaker"], 
                        "text": t["text"], 
                        "match_term": term, 
                        "domain": t.get("domain", ""), 
                        "intent": t.get("intent", ""), 
                    }) 
 
    for h in hits.values(): 
        h.matched_turns.sort(key=lambda x: (x["call_id"], x["turn_id"])) 
    return list(hits.values())